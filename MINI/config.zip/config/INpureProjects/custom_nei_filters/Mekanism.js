if (FML.isModLoaded("Mekanism")){
    NEI.override_block("Mekanism:GasTank", [100]);
	NEI.override_block("Mekanism:*PlasticBlock", [0]);
	NEI.override("Mekanism:Balloon", [0]);
	NEI.override("Mekanism:GlowPanel", [0]);
}