if (FML.isModLoaded("ThermalExpansion") && ThermalExpansion_enabled){
    NEI.override_item("ThermalExpansion:florb", [0, 1]);
}